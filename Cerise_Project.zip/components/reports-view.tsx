"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import type { TimeEntry } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Download, Calendar, TrendingUp, Users, Clock, FileDown } from "lucide-react"
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, isWithinInterval } from "date-fns"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Line, LineChart } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { generatePayrollPDF } from "@/lib/pdf-generator"

export function ReportsView() {
  const { user } = useAuth()
  const [reportType, setReportType] = useState<string>("weekly")
  const [startDate, setStartDate] = useState(format(startOfWeek(new Date()), "yyyy-MM-dd"))
  const [endDate, setEndDate] = useState(format(endOfWeek(new Date()), "yyyy-MM-dd"))
  const [selectedEmployee, setSelectedEmployee] = useState<string>("all")
  const [reportData, setReportData] = useState<any>(null)
  const [employees, setEmployees] = useState<{ id: string; name: string; employeeId: string; department: string }[]>([])

  useEffect(() => {
    loadEmployees()
  }, [])

  useEffect(() => {
    generateReport()
  }, [reportType, startDate, endDate, selectedEmployee])

  const loadEmployees = () => {
    const timeEntries: TimeEntry[] = JSON.parse(localStorage.getItem("time_entries") || "[]")

    // Get demo users for employee info
    const demoUsers = [
      { id: "1", name: "Sarah Johnson", employeeId: "EMP001", department: "Human Resources" },
      { id: "2", name: "Michael Chen", employeeId: "EMP002", department: "Finance" },
      { id: "3", name: "Emily Rodriguez", employeeId: "EMP003", department: "Finance" },
    ]

    const uniqueEmployees = Array.from(
      new Map(
        timeEntries.map((entry) => {
          const demoUser = demoUsers.find((u) => u.id === entry.userId)
          return [
            entry.userId,
            {
              id: entry.userId,
              name: entry.userName,
              employeeId: demoUser?.employeeId || `EMP${entry.userId.padStart(3, "0")}`,
              department: demoUser?.department || "General",
            },
          ]
        }),
      ).values(),
    )
    setEmployees(uniqueEmployees)
  }

  const generateReport = () => {
    const timeEntries: TimeEntry[] = JSON.parse(localStorage.getItem("time_entries") || "[]")
    const start = new Date(startDate)
    const end = new Date(endDate)

    // Filter entries
    const filteredEntries = timeEntries.filter((entry) => {
      const entryDate = new Date(entry.date)
      const inDateRange = isWithinInterval(entryDate, { start, end })
      const matchesEmployee = selectedEmployee === "all" || entry.userId === selectedEmployee
      return inDateRange && matchesEmployee && entry.clockOut
    })

    // Calculate summary statistics
    const totalHours = filteredEntries.reduce((sum, entry) => sum + entry.totalHours, 0)
    const approvedHours = filteredEntries
      .filter((e) => e.status === "approved")
      .reduce((sum, e) => sum + e.totalHours, 0)
    const pendingHours = filteredEntries.filter((e) => e.status === "pending").reduce((sum, e) => sum + e.totalHours, 0)
    const totalEntries = filteredEntries.length
    const uniqueEmployeesCount = new Set(filteredEntries.map((e) => e.userId)).size

    // Group by employee
    const byEmployee = filteredEntries.reduce((acc: any, entry) => {
      if (!acc[entry.userName]) {
        acc[entry.userName] = { name: entry.userName, hours: 0, entries: 0 }
      }
      acc[entry.userName].hours += entry.totalHours
      acc[entry.userName].entries += 1
      return acc
    }, {})

    const employeeData = Object.values(byEmployee).sort((a: any, b: any) => b.hours - a.hours)

    // Group by date for trend chart
    const byDate = filteredEntries.reduce((acc: any, entry) => {
      const date = entry.date
      if (!acc[date]) {
        acc[date] = { date, hours: 0, entries: 0 }
      }
      acc[date].hours += entry.totalHours
      acc[date].entries += 1
      return acc
    }, {})

    const trendData = Object.values(byDate).sort((a: any, b: any) => a.date.localeCompare(b.date))

    // Group by project
    const byProject = filteredEntries.reduce((acc: any, entry) => {
      const project = entry.projectCode || "No Project"
      if (!acc[project]) {
        acc[project] = { project, hours: 0, entries: 0 }
      }
      acc[project].hours += entry.totalHours
      acc[project].entries += 1
      return acc
    }, {})

    const projectData = Object.values(byProject).sort((a: any, b: any) => b.hours - a.hours)

    setReportData({
      summary: {
        totalHours: totalHours.toFixed(1),
        approvedHours: approvedHours.toFixed(1),
        pendingHours: pendingHours.toFixed(1),
        totalEntries,
        uniqueEmployees: uniqueEmployeesCount,
        avgHoursPerDay: (totalHours / Math.max(1, trendData.length)).toFixed(1),
      },
      employeeData,
      trendData,
      projectData,
      filteredEntries,
    })
  }

  const handleQuickDateRange = (range: string) => {
    const today = new Date()
    switch (range) {
      case "today":
        setStartDate(format(today, "yyyy-MM-dd"))
        setEndDate(format(today, "yyyy-MM-dd"))
        break
      case "week":
        setStartDate(format(startOfWeek(today), "yyyy-MM-dd"))
        setEndDate(format(endOfWeek(today), "yyyy-MM-dd"))
        break
      case "month":
        setStartDate(format(startOfMonth(today), "yyyy-MM-dd"))
        setEndDate(format(endOfMonth(today), "yyyy-MM-dd"))
        break
    }
    setReportType(range)
  }

  const exportToCSV = () => {
    if (!reportData) return

    const csvRows = [
      ["TimeTrack Pro - Time Report"],
      [`Report Period: ${format(new Date(startDate), "MMM d, yyyy")} - ${format(new Date(endDate), "MMM d, yyyy")}`],
      [`Generated: ${format(new Date(), "MMM d, yyyy h:mm a")}`],
      [`Generated by: ${user?.name}`],
      [""],
      ["Summary Statistics"],
      ["Total Hours", reportData.summary.totalHours],
      ["Approved Hours", reportData.summary.approvedHours],
      ["Pending Hours", reportData.summary.pendingHours],
      ["Total Entries", reportData.summary.totalEntries],
      ["Unique Employees", reportData.summary.uniqueEmployees],
      [""],
      ["Employee Breakdown"],
      ["Employee Name", "Total Hours", "Number of Entries"],
      ...reportData.employeeData.map((emp: any) => [emp.name, emp.hours.toFixed(2), emp.entries]),
      [""],
      ["Project Breakdown"],
      ["Project Code", "Total Hours", "Number of Entries"],
      ...reportData.projectData.map((proj: any) => [proj.project, proj.hours.toFixed(2), proj.entries]),
    ]

    const csvContent = csvRows.map((row) => row.join(",")).join("\n")
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `timesheet-report-${format(new Date(), "yyyy-MM-dd")}.csv`
    a.click()
    window.URL.revokeObjectURL(url)

    // Log audit trail
    const auditLogs = JSON.parse(localStorage.getItem("audit_logs") || "[]")
    auditLogs.push({
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      action: "EXPORT_REPORT",
      details: `Exported CSV report for ${startDate} to ${endDate}`,
      timestamp: new Date().toISOString(),
    })
    localStorage.setItem("audit_logs", JSON.stringify(auditLogs))
  }

  const exportToPDF = async () => {
    if (!reportData || selectedEmployee === "all") {
      alert("Please select a specific employee to generate a payroll PDF")
      return
    }

    const employee = employees.find((e) => e.id === selectedEmployee)
    if (!employee) return

    await generatePayrollPDF(reportData.filteredEntries, employee, startDate, endDate, user!.name)

    // Log audit trail
    const auditLogs = JSON.parse(localStorage.getItem("audit_logs") || "[]")
    auditLogs.push({
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      action: "EXPORT_PDF",
      details: `Generated payroll PDF for ${employee.name} (${startDate} to ${endDate})`,
      timestamp: new Date().toISOString(),
    })
    localStorage.setItem("audit_logs", JSON.stringify(auditLogs))
  }

  if (!reportData) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-(--color-primary)"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Report Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Time Reports & Analytics
          </CardTitle>
          <CardDescription>Generate detailed reports and analyze timesheet data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Quick Range</Label>
              <Select value={reportType} onValueChange={handleQuickDateRange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="start-date">Start Date</Label>
              <Input
                id="start-date"
                type="date"
                value={startDate}
                onChange={(e) => {
                  setStartDate(e.target.value)
                  setReportType("custom")
                }}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="end-date">End Date</Label>
              <Input
                id="end-date"
                type="date"
                value={endDate}
                onChange={(e) => {
                  setEndDate(e.target.value)
                  setReportType("custom")
                }}
              />
            </div>

            <div className="space-y-2">
              <Label>Employee Filter</Label>
              <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                <SelectTrigger>
                  <SelectValue placeholder="All employees" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Employees</SelectItem>
                  {employees.map((emp) => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <Button onClick={exportToCSV} className="gap-2 bg-(--color-primary)">
              <Download className="w-4 h-4" />
              Export to CSV
            </Button>
            <Button onClick={exportToPDF} variant="outline" className="gap-2 bg-transparent">
              <FileDown className="w-4 h-4" />
              Generate Payroll PDF
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Total Hours</p>
                <p className="text-3xl font-bold text-(--color-primary)">{reportData.summary.totalHours}</p>
              </div>
              <Clock className="w-8 h-8 text-(--color-primary) opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Approved Hours</p>
                <p className="text-3xl font-bold text-green-600">{reportData.summary.approvedHours}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Pending Hours</p>
                <p className="text-3xl font-bold text-yellow-600">{reportData.summary.pendingHours}</p>
              </div>
              <Calendar className="w-8 h-8 text-yellow-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Total Entries</p>
                <p className="text-3xl font-bold text-(--color-primary)">{reportData.summary.totalEntries}</p>
              </div>
              <FileText className="w-8 h-8 text-(--color-primary) opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Employees</p>
                <p className="text-3xl font-bold text-(--color-primary)">{reportData.summary.uniqueEmployees}</p>
              </div>
              <Users className="w-8 h-8 text-(--color-primary) opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Avg Hours/Day</p>
                <p className="text-3xl font-bold text-(--color-primary)">{reportData.summary.avgHoursPerDay}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-(--color-primary) opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Hours Trend Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Hours Trend</CardTitle>
          <CardDescription>Daily hours worked over the selected period</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              hours: {
                label: "Hours",
                color: "hsl(var(--chart-1))",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={reportData.trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tickFormatter={(value) => format(new Date(value), "MMM d")} fontSize={12} />
                <YAxis fontSize={12} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="hours" stroke="var(--color-hours)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Employee Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Hours by Employee</CardTitle>
          <CardDescription>Total hours worked by each employee</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              hours: {
                label: "Hours",
                color: "hsl(var(--chart-2))",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={reportData.employeeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis fontSize={12} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="hours" fill="var(--color-hours)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Project Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Hours by Project</CardTitle>
          <CardDescription>Time allocation across different projects</CardDescription>
        </CardHeader>
        <CardContent>
          {reportData.projectData.length === 0 ? (
            <p className="text-center text-slate-500 py-8">No project data available</p>
          ) : (
            <div className="space-y-3">
              {reportData.projectData.map((project: any, index: number) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-slate-900">{project.project}</p>
                    <p className="text-sm text-slate-600">{project.entries} entries</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-(--color-primary)">{project.hours.toFixed(1)}</p>
                    <p className="text-xs text-slate-500">hours</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import type { TimeEntry } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, TrendingUp, Calendar, Users, CheckCircle, AlertCircle } from "lucide-react"
import { format, startOfWeek, endOfWeek, isWithinInterval } from "date-fns"

export function OverviewView() {
  const { user } = useAuth()
  const [stats, setStats] = useState({
    todayHours: 0,
    weekHours: 0,
    pendingApprovals: 0,
    teamMembers: 0,
    thisWeekEntries: 0,
    avgDailyHours: 0,
  })
  const [recentActivity, setRecentActivity] = useState<string[]>([])

  useEffect(() => {
    calculateStats()
    loadRecentActivity()
  }, [user])

  const calculateStats = () => {
    const timeEntries: TimeEntry[] = JSON.parse(localStorage.getItem("time_entries") || "[]")
    const today = format(new Date(), "yyyy-MM-dd")
    const weekStart = startOfWeek(new Date())
    const weekEnd = endOfWeek(new Date())

    let todayHours = 0
    let weekHours = 0
    let pendingApprovals = 0
    let thisWeekEntries = 0

    if (user?.role === "employee") {
      // Employee stats
      const userEntries = timeEntries.filter((e) => e.userId === user.id)
      todayHours = userEntries.filter((e) => e.date === today && e.clockOut).reduce((sum, e) => sum + e.totalHours, 0)

      weekHours = userEntries
        .filter((e) => {
          const entryDate = new Date(e.date)
          return isWithinInterval(entryDate, { start: weekStart, end: weekEnd }) && e.clockOut
        })
        .reduce((sum, e) => sum + e.totalHours, 0)

      pendingApprovals = userEntries.filter((e) => e.status === "pending").length

      thisWeekEntries = userEntries.filter((e) => {
        const entryDate = new Date(e.date)
        return isWithinInterval(entryDate, { start: weekStart, end: weekEnd })
      }).length
    } else {
      // Manager/Admin stats
      const relevantEntries = user?.role === "admin" ? timeEntries : timeEntries.filter((e) => e.userId !== "1")

      weekHours = relevantEntries
        .filter((e) => {
          const entryDate = new Date(e.date)
          return (
            isWithinInterval(entryDate, { start: weekStart, end: weekEnd }) && e.clockOut && e.status === "approved"
          )
        })
        .reduce((sum, e) => sum + e.totalHours, 0)

      pendingApprovals = relevantEntries.filter((e) => e.status === "pending").length

      thisWeekEntries = relevantEntries.filter((e) => {
        const entryDate = new Date(e.date)
        return isWithinInterval(entryDate, { start: weekStart, end: weekEnd })
      }).length

      // Count unique users
      const uniqueUsers = new Set(relevantEntries.map((e) => e.userId))
      setStats((prev) => ({ ...prev, teamMembers: uniqueUsers.size }))
    }

    const avgDailyHours = thisWeekEntries > 0 ? weekHours / 5 : 0

    setStats({
      todayHours,
      weekHours,
      pendingApprovals,
      teamMembers: stats.teamMembers,
      thisWeekEntries,
      avgDailyHours,
    })
  }

  const loadRecentActivity = () => {
    const auditLogs = JSON.parse(localStorage.getItem("audit_logs") || "[]")
    const userLogs = user?.role === "employee" ? auditLogs.filter((log: any) => log.userId === user.id) : auditLogs

    const recent = userLogs
      .slice(-5)
      .reverse()
      .map((log: any) => `${log.action.replace(/_/g, " ")} - ${format(new Date(log.timestamp), "MMM d, h:mm a")}`)

    setRecentActivity(recent)
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-700 rounded-lg p-8 text-white">
        <h2 className="text-3xl font-bold mb-2">Welcome back, {user?.name}!</h2>
        <p className="text-slate-300 text-lg">
          {user?.role === "employee"
            ? "Track your time and manage your timesheets"
            : "Manage your team's timesheets and approvals"}
        </p>
        <p className="text-slate-400 text-sm mt-2">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {user?.role === "employee" && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Hours</CardTitle>
              <Clock className="h-4 w-4 text-slate-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-(--color-primary)">{stats.todayHours.toFixed(1)}</div>
              <p className="text-xs text-slate-600 mt-1">Hours worked today</p>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Week</CardTitle>
            <Calendar className="h-4 w-4 text-slate-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-(--color-primary)">{stats.weekHours.toFixed(1)}</div>
            <p className="text-xs text-slate-600 mt-1">
              {user?.role === "employee" ? "Hours logged this week" : "Team hours this week"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {user?.role === "employee" ? "Pending" : "Awaiting Review"}
            </CardTitle>
            <AlertCircle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pendingApprovals}</div>
            <p className="text-xs text-slate-600 mt-1">
              {user?.role === "employee" ? "Entries pending approval" : "Timesheets to review"}
            </p>
          </CardContent>
        </Card>

        {(user?.role === "manager" || user?.role === "admin") && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Team Members</CardTitle>
              <Users className="h-4 w-4 text-slate-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-(--color-primary)">{stats.teamMembers}</div>
              <p className="text-xs text-slate-600 mt-1">Active employees</p>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Weekly Entries</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-(--color-primary)">{stats.thisWeekEntries}</div>
            <p className="text-xs text-slate-600 mt-1">Time entries this week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Daily Average</CardTitle>
            <TrendingUp className="h-4 w-4 text-slate-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-(--color-primary)">{stats.avgDailyHours.toFixed(1)}</div>
            <p className="text-xs text-slate-600 mt-1">Average hours per day</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Your latest actions in the system</CardDescription>
        </CardHeader>
        <CardContent>
          {recentActivity.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-4">No recent activity</p>
          ) : (
            <ul className="space-y-2">
              {recentActivity.map((activity, index) => (
                <li key={index} className="text-sm text-slate-700 flex items-start gap-2">
                  <span className="text-slate-400 mt-1">•</span>
                  <span>{activity}</span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

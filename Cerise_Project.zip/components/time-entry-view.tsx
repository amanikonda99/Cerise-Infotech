"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import type { TimeEntry } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Clock, Play, Square, Calendar, Plus, Trash2 } from "lucide-react"
import { format } from "date-fns"

export function TimeEntryView() {
  const { user } = useAuth()
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([])
  const [isClockedIn, setIsClockedIn] = useState(false)
  const [currentEntry, setCurrentEntry] = useState<TimeEntry | null>(null)
  const [elapsedTime, setElapsedTime] = useState(0)
  const [showManualEntry, setShowManualEntry] = useState(false)

  // Manual entry form state
  const [manualDate, setManualDate] = useState(format(new Date(), "yyyy-MM-dd"))
  const [manualClockIn, setManualClockIn] = useState("09:00")
  const [manualClockOut, setManualClockOut] = useState("17:00")
  const [manualBreak, setManualBreak] = useState("60")
  const [manualNotes, setManualNotes] = useState("")
  const [manualProject, setManualProject] = useState("")

  useEffect(() => {
    // Load time entries from localStorage
    const stored = localStorage.getItem("time_entries")
    if (stored) {
      const allEntries = JSON.parse(stored)
      const userEntries = allEntries.filter((entry: TimeEntry) => entry.userId === user?.id)
      setTimeEntries(userEntries)

      // Check if user is currently clocked in
      const activeEntry = userEntries.find((entry: TimeEntry) => entry.clockOut === null)
      if (activeEntry) {
        setIsClockedIn(true)
        setCurrentEntry(activeEntry)
      }
    }
  }, [user])

  useEffect(() => {
    // Update elapsed time every second when clocked in
    if (isClockedIn && currentEntry) {
      const interval = setInterval(() => {
        const start = new Date(currentEntry.clockIn).getTime()
        const now = new Date().getTime()
        setElapsedTime(Math.floor((now - start) / 1000))
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [isClockedIn, currentEntry])

  const formatElapsedTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleClockIn = () => {
    const newEntry: TimeEntry = {
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      date: format(new Date(), "yyyy-MM-dd"),
      clockIn: new Date().toISOString(),
      clockOut: null,
      breakMinutes: 0,
      totalHours: 0,
      status: "pending",
      notes: "",
    }

    const allEntries = JSON.parse(localStorage.getItem("time_entries") || "[]")
    allEntries.push(newEntry)
    localStorage.setItem("time_entries", JSON.stringify(allEntries))

    setTimeEntries([newEntry, ...timeEntries])
    setCurrentEntry(newEntry)
    setIsClockedIn(true)

    // Log audit trail
    const auditLogs = JSON.parse(localStorage.getItem("audit_logs") || "[]")
    auditLogs.push({
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      action: "CLOCK_IN",
      details: `Clocked in at ${format(new Date(), "HH:mm:ss")}`,
      timestamp: new Date().toISOString(),
    })
    localStorage.setItem("audit_logs", JSON.stringify(auditLogs))
  }

  const handleClockOut = () => {
    if (!currentEntry) return

    const clockOutTime = new Date()
    const clockInTime = new Date(currentEntry.clockIn)
    const totalMinutes = Math.floor((clockOutTime.getTime() - clockInTime.getTime()) / 60000)
    const totalHours = Number(((totalMinutes - currentEntry.breakMinutes) / 60).toFixed(2))

    const updatedEntry = {
      ...currentEntry,
      clockOut: clockOutTime.toISOString(),
      totalHours,
    }

    const allEntries = JSON.parse(localStorage.getItem("time_entries") || "[]")
    const updatedAllEntries = allEntries.map((entry: TimeEntry) =>
      entry.id === currentEntry.id ? updatedEntry : entry,
    )
    localStorage.setItem("time_entries", JSON.stringify(updatedAllEntries))

    setTimeEntries(timeEntries.map((entry) => (entry.id === currentEntry.id ? updatedEntry : entry)))
    setCurrentEntry(null)
    setIsClockedIn(false)
    setElapsedTime(0)

    // Log audit trail
    const auditLogs = JSON.parse(localStorage.getItem("audit_logs") || "[]")
    auditLogs.push({
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      action: "CLOCK_OUT",
      details: `Clocked out at ${format(clockOutTime, "HH:mm:ss")} - Total: ${totalHours} hours`,
      timestamp: new Date().toISOString(),
    })
    localStorage.setItem("audit_logs", JSON.stringify(auditLogs))
  }

  const handleManualEntry = () => {
    const clockInDate = new Date(`${manualDate}T${manualClockIn}`)
    const clockOutDate = new Date(`${manualDate}T${manualClockOut}`)
    const totalMinutes = Math.floor((clockOutDate.getTime() - clockInDate.getTime()) / 60000)
    const totalHours = Number(((totalMinutes - Number(manualBreak)) / 60).toFixed(2))

    const newEntry: TimeEntry = {
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      date: manualDate,
      clockIn: clockInDate.toISOString(),
      clockOut: clockOutDate.toISOString(),
      breakMinutes: Number(manualBreak),
      totalHours,
      status: "pending",
      notes: manualNotes,
      projectCode: manualProject || undefined,
    }

    const allEntries = JSON.parse(localStorage.getItem("time_entries") || "[]")
    allEntries.push(newEntry)
    localStorage.setItem("time_entries", JSON.stringify(allEntries))

    setTimeEntries([newEntry, ...timeEntries])
    setShowManualEntry(false)

    // Reset form
    setManualDate(format(new Date(), "yyyy-MM-dd"))
    setManualClockIn("09:00")
    setManualClockOut("17:00")
    setManualBreak("60")
    setManualNotes("")
    setManualProject("")

    // Log audit trail
    const auditLogs = JSON.parse(localStorage.getItem("audit_logs") || "[]")
    auditLogs.push({
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      action: "MANUAL_ENTRY",
      details: `Added manual time entry for ${manualDate} - ${totalHours} hours`,
      timestamp: new Date().toISOString(),
    })
    localStorage.setItem("audit_logs", JSON.stringify(auditLogs))
  }

  const handleDeleteEntry = (entryId: string) => {
    const allEntries = JSON.parse(localStorage.getItem("time_entries") || "[]")
    const updatedEntries = allEntries.filter((entry: TimeEntry) => entry.id !== entryId)
    localStorage.setItem("time_entries", JSON.stringify(updatedEntries))

    setTimeEntries(timeEntries.filter((entry) => entry.id !== entryId))

    // Log audit trail
    const auditLogs = JSON.parse(localStorage.getItem("audit_logs") || "[]")
    auditLogs.push({
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      action: "DELETE_ENTRY",
      details: `Deleted time entry ${entryId}`,
      timestamp: new Date().toISOString(),
    })
    localStorage.setItem("audit_logs", JSON.stringify(auditLogs))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800 border-green-200"
      case "rejected":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
    }
  }

  return (
    <div className="space-y-6">
      {/* Clock In/Out Card */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Time Clock
          </CardTitle>
          <CardDescription>Clock in and out to track your work hours</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              {isClockedIn ? (
                <div className="space-y-2">
                  <p className="text-sm text-slate-600">Currently clocked in</p>
                  <p className="text-3xl font-mono font-bold text-(--color-primary)">
                    {formatElapsedTime(elapsedTime)}
                  </p>
                  <p className="text-xs text-slate-500">
                    Started at {currentEntry && format(new Date(currentEntry.clockIn), "h:mm a")}
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-sm text-slate-600">Ready to start your shift</p>
                  <p className="text-lg font-medium text-slate-900">Click Clock In to begin</p>
                </div>
              )}
            </div>
            <div className="flex gap-3">
              {isClockedIn ? (
                <Button onClick={handleClockOut} size="lg" variant="destructive" className="gap-2">
                  <Square className="w-5 h-5" />
                  Clock Out
                </Button>
              ) : (
                <Button onClick={handleClockIn} size="lg" className="gap-2 bg-(--color-primary)">
                  <Play className="w-5 h-5" />
                  Clock In
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Manual Entry Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Manual Time Entry
              </CardTitle>
              <CardDescription>Add time entries for past dates or corrections</CardDescription>
            </div>
            <Button onClick={() => setShowManualEntry(!showManualEntry)} variant="outline" className="gap-2">
              <Plus className="w-4 h-4" />
              {showManualEntry ? "Cancel" : "Add Entry"}
            </Button>
          </div>
        </CardHeader>
        {showManualEntry && (
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="manual-date">Date</Label>
                <Input
                  id="manual-date"
                  type="date"
                  value={manualDate}
                  onChange={(e) => setManualDate(e.target.value)}
                  max={format(new Date(), "yyyy-MM-dd")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manual-project">Project Code (Optional)</Label>
                <Input
                  id="manual-project"
                  placeholder="e.g., FIN-2024-001"
                  value={manualProject}
                  onChange={(e) => setManualProject(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manual-clock-in">Clock In Time</Label>
                <Input
                  id="manual-clock-in"
                  type="time"
                  value={manualClockIn}
                  onChange={(e) => setManualClockIn(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manual-clock-out">Clock Out Time</Label>
                <Input
                  id="manual-clock-out"
                  type="time"
                  value={manualClockOut}
                  onChange={(e) => setManualClockOut(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manual-break">Break Duration (minutes)</Label>
                <Input
                  id="manual-break"
                  type="number"
                  value={manualBreak}
                  onChange={(e) => setManualBreak(e.target.value)}
                  min="0"
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="manual-notes">Notes</Label>
                <Textarea
                  id="manual-notes"
                  placeholder="Add any relevant notes about this time entry..."
                  value={manualNotes}
                  onChange={(e) => setManualNotes(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="col-span-2">
                <Button onClick={handleManualEntry} className="w-full bg-(--color-primary)">
                  Add Time Entry
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Time Entries History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Time Entries</CardTitle>
          <CardDescription>Your timesheet history and status</CardDescription>
        </CardHeader>
        <CardContent>
          {timeEntries.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No time entries yet. Clock in to start tracking your time.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {timeEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-slate-50"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <p className="font-medium text-slate-900">{format(new Date(entry.date), "EEEE, MMMM d, yyyy")}</p>
                      <Badge className={getStatusColor(entry.status)}>{entry.status}</Badge>
                      {entry.projectCode && (
                        <Badge variant="outline" className="font-mono text-xs">
                          {entry.projectCode}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-slate-600">
                      <span>
                        {format(new Date(entry.clockIn), "h:mm a")} -{" "}
                        {entry.clockOut ? format(new Date(entry.clockOut), "h:mm a") : "In Progress"}
                      </span>
                      {entry.clockOut && (
                        <>
                          <span>•</span>
                          <span className="font-medium">{entry.totalHours} hours</span>
                          {entry.breakMinutes > 0 && (
                            <>
                              <span>•</span>
                              <span>{entry.breakMinutes} min break</span>
                            </>
                          )}
                        </>
                      )}
                    </div>
                    {entry.notes && <p className="text-sm text-slate-500 mt-1">{entry.notes}</p>}
                    {entry.approvedBy && (
                      <p className="text-xs text-slate-500 mt-1">
                        Approved by {entry.approvedBy} on {format(new Date(entry.approvedAt!), "MMM d, yyyy")}
                      </p>
                    )}
                  </div>
                  {entry.status === "pending" && entry.clockOut && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteEntry(entry.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

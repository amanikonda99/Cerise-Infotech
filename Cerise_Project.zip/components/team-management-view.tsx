"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import type { TimeEntry } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Check, X, Clock, Search, Filter, Users } from "lucide-react"
import { format } from "date-fns"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function TeamManagementView() {
  const { user } = useAuth()
  const [allTimeEntries, setAllTimeEntries] = useState<TimeEntry[]>([])
  const [filteredEntries, setFilteredEntries] = useState<TimeEntry[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [stats, setStats] = useState({
    pending: 0,
    approved: 0,
    rejected: 0,
    totalHours: 0,
  })

  useEffect(() => {
    loadTimeEntries()
  }, [])

  useEffect(() => {
    filterEntries()
  }, [allTimeEntries, searchTerm, statusFilter])

  const loadTimeEntries = () => {
    const stored = localStorage.getItem("time_entries")
    if (stored) {
      const entries: TimeEntry[] = JSON.parse(stored)

      // Filter based on role
      let relevantEntries = entries
      if (user?.role === "manager") {
        // Managers see only their department
        relevantEntries = entries.filter((entry) => {
          // In a real app, we'd check department. For demo, show all except admin entries
          return entry.userId !== "1"
        })
      }

      setAllTimeEntries(relevantEntries)

      // Calculate stats
      const pending = relevantEntries.filter((e) => e.status === "pending").length
      const approved = relevantEntries.filter((e) => e.status === "approved").length
      const rejected = relevantEntries.filter((e) => e.status === "rejected").length
      const totalHours = relevantEntries
        .filter((e) => e.status === "approved")
        .reduce((sum, e) => sum + e.totalHours, 0)

      setStats({ pending, approved, rejected, totalHours })
    }
  }

  const filterEntries = () => {
    let filtered = allTimeEntries

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(
        (entry) =>
          entry.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          entry.projectCode?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          entry.notes.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filter by status
    if (statusFilter !== "all") {
      filtered = filtered.filter((entry) => entry.status === statusFilter)
    }

    // Sort by date (newest first)
    filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    setFilteredEntries(filtered)
  }

  const handleApprove = (entryId: string) => {
    updateEntryStatus(entryId, "approved")
  }

  const handleReject = (entryId: string) => {
    updateEntryStatus(entryId, "rejected")
  }

  const updateEntryStatus = (entryId: string, status: "approved" | "rejected") => {
    const allEntries = JSON.parse(localStorage.getItem("time_entries") || "[]")
    const updatedEntries = allEntries.map((entry: TimeEntry) =>
      entry.id === entryId
        ? {
            ...entry,
            status,
            approvedBy: user?.name,
            approvedAt: new Date().toISOString(),
          }
        : entry,
    )
    localStorage.setItem("time_entries", JSON.stringify(updatedEntries))

    // Update local state
    setAllTimeEntries(updatedEntries)

    // Log audit trail
    const auditLogs = JSON.parse(localStorage.getItem("audit_logs") || "[]")
    const entry = allEntries.find((e: TimeEntry) => e.id === entryId)
    auditLogs.push({
      id: Date.now().toString(),
      userId: user!.id,
      userName: user!.name,
      action: status === "approved" ? "APPROVE_TIMESHEET" : "REJECT_TIMESHEET",
      details: `${status === "approved" ? "Approved" : "Rejected"} timesheet for ${entry.userName} - ${entry.date}`,
      timestamp: new Date().toISOString(),
    })
    localStorage.setItem("audit_logs", JSON.stringify(auditLogs))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800 border-green-200"
      case "rejected":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
    }
  }

  const pendingEntries = filteredEntries.filter((e) => e.status === "pending")
  const reviewedEntries = filteredEntries.filter((e) => e.status !== "pending")

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Pending Approval</p>
                <p className="text-3xl font-bold text-yellow-600">{stats.pending}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Approved</p>
                <p className="text-3xl font-bold text-green-600">{stats.approved}</p>
              </div>
              <Check className="w-8 h-8 text-green-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Rejected</p>
                <p className="text-3xl font-bold text-red-600">{stats.rejected}</p>
              </div>
              <X className="w-8 h-8 text-red-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Total Hours</p>
                <p className="text-3xl font-bold text-(--color-primary)">{stats.totalHours.toFixed(1)}</p>
              </div>
              <Users className="w-8 h-8 text-(--color-primary) opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Team Timesheets</CardTitle>
          <CardDescription>Review and approve employee time entries</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by employee name, project code, or notes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Tabs defaultValue="pending" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="pending">Pending Review ({pendingEntries.length})</TabsTrigger>
              <TabsTrigger value="reviewed">Reviewed ({reviewedEntries.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="pending" className="space-y-3 mt-4">
              {pendingEntries.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <Check className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No pending timesheets to review</p>
                </div>
              ) : (
                pendingEntries.map((entry) => (
                  <div
                    key={entry.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-slate-50"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <p className="font-medium text-slate-900">{entry.userName}</p>
                        <span className="text-slate-400">•</span>
                        <p className="text-sm text-slate-600">{format(new Date(entry.date), "EEEE, MMM d, yyyy")}</p>
                        {entry.projectCode && (
                          <>
                            <span className="text-slate-400">•</span>
                            <Badge variant="outline" className="font-mono text-xs">
                              {entry.projectCode}
                            </Badge>
                          </>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <span>
                          {format(new Date(entry.clockIn), "h:mm a")} -{" "}
                          {entry.clockOut ? format(new Date(entry.clockOut), "h:mm a") : "In Progress"}
                        </span>
                        {entry.clockOut && (
                          <>
                            <span>•</span>
                            <span className="font-medium text-(--color-primary)">{entry.totalHours} hours</span>
                            {entry.breakMinutes > 0 && (
                              <>
                                <span>•</span>
                                <span>{entry.breakMinutes} min break</span>
                              </>
                            )}
                          </>
                        )}
                      </div>
                      {entry.notes && <p className="text-sm text-slate-500 mt-1 italic">Note: {entry.notes}</p>}
                    </div>
                    <div className="flex gap-2 ml-4">
                      <Button
                        onClick={() => handleReject(entry.id)}
                        variant="outline"
                        size="sm"
                        className="gap-2 text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                      >
                        <X className="w-4 h-4" />
                        Reject
                      </Button>
                      <Button
                        onClick={() => handleApprove(entry.id)}
                        size="sm"
                        className="gap-2 bg-green-600 hover:bg-green-700"
                      >
                        <Check className="w-4 h-4" />
                        Approve
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </TabsContent>

            <TabsContent value="reviewed" className="space-y-3 mt-4">
              {reviewedEntries.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No reviewed timesheets yet</p>
                </div>
              ) : (
                reviewedEntries.map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between p-4 border rounded-lg bg-slate-50">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <p className="font-medium text-slate-900">{entry.userName}</p>
                        <span className="text-slate-400">•</span>
                        <p className="text-sm text-slate-600">{format(new Date(entry.date), "EEEE, MMM d, yyyy")}</p>
                        <Badge className={getStatusColor(entry.status)}>{entry.status}</Badge>
                        {entry.projectCode && (
                          <Badge variant="outline" className="font-mono text-xs">
                            {entry.projectCode}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <span>
                          {format(new Date(entry.clockIn), "h:mm a")} -{" "}
                          {entry.clockOut ? format(new Date(entry.clockOut), "h:mm a") : "In Progress"}
                        </span>
                        {entry.clockOut && (
                          <>
                            <span>•</span>
                            <span className="font-medium">{entry.totalHours} hours</span>
                          </>
                        )}
                      </div>
                      {entry.approvedBy && (
                        <p className="text-xs text-slate-500 mt-1">
                          Reviewed by {entry.approvedBy} on{" "}
                          {format(new Date(entry.approvedAt!), "MMM d, yyyy 'at' h:mm a")}
                        </p>
                      )}
                    </div>
                  </div>
                ))
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

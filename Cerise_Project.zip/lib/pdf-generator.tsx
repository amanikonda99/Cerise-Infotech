import type { TimeEntry } from "./types"
import { format } from "date-fns"

export async function generatePayrollPDF(
  entries: TimeEntry[],
  employee: { name: string; employeeId: string; department: string },
  startDate: string,
  endDate: string,
  generatedBy: string,
): Promise<void> {
  // Calculate totals
  const totalHours = entries.reduce((sum, entry) => sum + entry.totalHours, 0)
  const approvedHours = entries.filter((e) => e.status === "approved").reduce((sum, e) => sum + e.totalHours, 0)
  const pendingHours = entries.filter((e) => e.status === "pending").reduce((sum, e) => sum + e.totalHours, 0)

  // Create HTML content for PDF
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Payroll Report - ${employee.name}</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
          font-family: 'Arial', sans-serif; 
          padding: 40px; 
          color: #1e293b;
          line-height: 1.6;
        }
        .header { 
          border-bottom: 3px solid #1e293b; 
          padding-bottom: 20px; 
          margin-bottom: 30px;
        }
        .logo { 
          font-size: 24px; 
          font-weight: bold; 
          color: #1e293b;
          margin-bottom: 5px;
        }
        .subtitle { 
          color: #64748b; 
          font-size: 14px;
        }
        .info-section { 
          display: grid; 
          grid-template-columns: 1fr 1fr; 
          gap: 20px; 
          margin-bottom: 30px;
          background: #f8fafc;
          padding: 20px;
          border-radius: 8px;
        }
        .info-item { margin-bottom: 10px; }
        .info-label { 
          font-weight: 600; 
          color: #475569;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .info-value { 
          font-size: 16px; 
          color: #1e293b;
          margin-top: 2px;
        }
        .summary-cards {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 15px;
          margin-bottom: 30px;
        }
        .summary-card {
          background: #f8fafc;
          padding: 20px;
          border-radius: 8px;
          border: 1px solid #e2e8f0;
        }
        .summary-label {
          font-size: 12px;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 8px;
        }
        .summary-value {
          font-size: 32px;
          font-weight: bold;
          color: #1e293b;
        }
        .summary-unit {
          font-size: 14px;
          color: #64748b;
          margin-left: 4px;
        }
        table { 
          width: 100%; 
          border-collapse: collapse; 
          margin-bottom: 30px;
          font-size: 14px;
        }
        th { 
          background: #1e293b; 
          color: white; 
          padding: 12px; 
          text-align: left;
          font-weight: 600;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        td { 
          padding: 12px; 
          border-bottom: 1px solid #e2e8f0;
        }
        tr:hover { background: #f8fafc; }
        .status-badge {
          display: inline-block;
          padding: 4px 12px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .status-approved { background: #dcfce7; color: #166534; }
        .status-pending { background: #fef3c7; color: #854d0e; }
        .status-rejected { background: #fee2e2; color: #991b1b; }
        .footer { 
          margin-top: 40px; 
          padding-top: 20px; 
          border-top: 2px solid #e2e8f0;
          font-size: 12px;
          color: #64748b;
        }
        .signature-section {
          margin-top: 50px;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 40px;
        }
        .signature-line {
          border-top: 2px solid #1e293b;
          padding-top: 10px;
          margin-top: 60px;
        }
        .signature-label {
          font-size: 12px;
          color: #64748b;
          text-transform: uppercase;
        }
        @media print {
          body { padding: 20px; }
          .no-print { display: none; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="logo">TimeTrack Pro</div>
        <div class="subtitle">Financial Timesheet Management - Payroll Report</div>
      </div>

      <div class="info-section">
        <div>
          <div class="info-item">
            <div class="info-label">Employee Name</div>
            <div class="info-value">${employee.name}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Employee ID</div>
            <div class="info-value">${employee.employeeId}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Department</div>
            <div class="info-value">${employee.department}</div>
          </div>
        </div>
        <div>
          <div class="info-item">
            <div class="info-label">Report Period</div>
            <div class="info-value">${format(new Date(startDate), "MMM d, yyyy")} - ${format(new Date(endDate), "MMM d, yyyy")}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Generated Date</div>
            <div class="info-value">${format(new Date(), "MMM d, yyyy h:mm a")}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Generated By</div>
            <div class="info-value">${generatedBy}</div>
          </div>
        </div>
      </div>

      <div class="summary-cards">
        <div class="summary-card">
          <div class="summary-label">Total Hours</div>
          <div class="summary-value">${totalHours.toFixed(1)}<span class="summary-unit">hrs</span></div>
        </div>
        <div class="summary-card">
          <div class="summary-label">Approved Hours</div>
          <div class="summary-value">${approvedHours.toFixed(1)}<span class="summary-unit">hrs</span></div>
        </div>
        <div class="summary-card">
          <div class="summary-label">Pending Hours</div>
          <div class="summary-value">${pendingHours.toFixed(1)}<span class="summary-unit">hrs</span></div>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Clock In</th>
            <th>Clock Out</th>
            <th>Break (min)</th>
            <th>Hours</th>
            <th>Project</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${entries
            .map(
              (entry) => `
            <tr>
              <td>${format(new Date(entry.date), "MMM d, yyyy")}</td>
              <td>${format(new Date(entry.clockIn), "h:mm a")}</td>
              <td>${entry.clockOut ? format(new Date(entry.clockOut), "h:mm a") : "-"}</td>
              <td>${entry.breakMinutes}</td>
              <td><strong>${entry.totalHours.toFixed(2)}</strong></td>
              <td>${entry.projectCode || "-"}</td>
              <td><span class="status-badge status-${entry.status}">${entry.status}</span></td>
            </tr>
          `,
            )
            .join("")}
        </tbody>
      </table>

      ${
        entries.some((e) => e.notes)
          ? `
        <div style="margin-bottom: 30px;">
          <h3 style="margin-bottom: 15px; color: #1e293b;">Notes</h3>
          ${entries
            .filter((e) => e.notes)
            .map(
              (entry) => `
            <div style="margin-bottom: 10px; padding: 10px; background: #f8fafc; border-radius: 4px;">
              <strong>${format(new Date(entry.date), "MMM d")}:</strong> ${entry.notes}
            </div>
          `,
            )
            .join("")}
        </div>
      `
          : ""
      }

      <div class="signature-section">
        <div>
          <div class="signature-line">
            <div class="signature-label">Employee Signature</div>
          </div>
        </div>
        <div>
          <div class="signature-line">
            <div class="signature-label">Manager Approval</div>
          </div>
        </div>
      </div>

      <div class="footer">
        <p><strong>Confidential Document</strong></p>
        <p>This payroll report is generated by TimeTrack Pro and contains confidential employee information. 
        All hours listed have been recorded in accordance with company timekeeping policies. 
        For questions or discrepancies, please contact Human Resources.</p>
        <p style="margin-top: 10px;">Document ID: ${Date.now()} | Generated: ${format(new Date(), "yyyy-MM-dd HH:mm:ss")}</p>
      </div>
    </body>
    </html>
  `

  // Create a blob and download
  const blob = new Blob([htmlContent], { type: "text/html" })
  const url = window.URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = `payroll-${employee.employeeId}-${format(new Date(), "yyyy-MM-dd")}.html`
  a.click()
  window.URL.revokeObjectURL(url)

  // Note: In a real application, you would use a library like jsPDF or send this to a backend service
  // that converts HTML to PDF. For this demo, we're downloading as HTML which can be printed to PDF.
}

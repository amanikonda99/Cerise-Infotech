export type UserRole = "admin" | "manager" | "employee"

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  department: string
  employeeId: string
  createdAt: string
}

export interface TimeEntry {
  id: string
  userId: string
  userName: string
  date: string
  clockIn: string
  clockOut: string | null
  breakMinutes: number
  totalHours: number
  status: "pending" | "approved" | "rejected"
  notes: string
  projectCode?: string
  approvedBy?: string
  approvedAt?: string
}

export interface AuditLog {
  id: string
  userId: string
  userName: string
  action: string
  details: string
  timestamp: string
  ipAddress?: string
}
